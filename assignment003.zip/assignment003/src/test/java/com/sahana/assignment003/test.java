package com.sahana.assignment003;

public class test  
	{ 
	customerTest c1; 
	@Before
	public void setUp() throws Exception
	{
	c1 = new customerTest();
	c1.setName("John"); 
	List<Item> listOfItems = new ArrayList<Item>();
	Item i1 = Mockito.mock(Item.class);
	Item i2 = Mockito.mock();
	Item i3 = Mockito.mock();
	listOfItems.add(i1);
	listOfItems.add(i2);
	listOfItems.add(i3); 
	c1.setListOfItems(listOfItems); 
	when(i1.getName()).thenReturn("Rice");
	when(i2.getName()).thenReturn("Tea");
	when(i3.getName()).thenReturn("Wheat"); 
	when(i1.getPrice("Rice")).thenReturn(100);
	when(i2.getPrice("Tea")).thenReturn(200);
	when(i3.getPrice("Wheat")).thenReturn(300);
	} 
	private void setListOfItems(List<Item> listOfItems) 
	{
	// TODO Auto-generated method stub
	} 
	private void setName(String string) 
	{
	// TODO Auto-generated method stub
	} 
	@Test
	public void testCustomerBill()
	{
	int billAmount = c1.calculateBill();
	Assert.assertEquals(600,billAmount);
	} 
	private int calculateBill() {
	// TODO Auto-generated method stub
	return 0;
	}
	}



