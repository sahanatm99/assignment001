package com.sahana.assignment001;

public class mathopeartion 
{
	public int addition(int a ,int b)
	{
	return a+b;
	}
	public int subtraction(int a ,int b)
	{
	return a-b;
	}
	public int multiply ( int a , int b)
	{
	return a*b;
	}
	public float division(float a ,float b)
	{
	if (b==0)
	throw new IllegalArgumentException("division by zero");
	return a/b;
	}
	public int factorial_num(int n){
	if (n<0)
	throw new IllegalArgumentException("input is lesser than zero");
	else if (n>15)
	throw new IllegalArgumentException("Input is greater than 15");
	else if (n == 0)
	return 1;
	else
	return(n * factorial_num(n-1));
	}
	public double power(double a , double b) {
	if(b>10)
	{
	throw new ArithmeticException("exponent greater than 10");
	}
	else
	return Math.pow(a,b);
	}
	}





