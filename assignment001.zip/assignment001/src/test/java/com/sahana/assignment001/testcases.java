package com.sahana.assignment001;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test; 

public class testcases 
{
	private MathOperations math;
	@BeforeEach
	void setUp() throws Exception 
	{
	math = new MathOperations();
	}
	@Test
	void additionTest() {
	assertEquals(12,math.addition(8,4));
	}
	@Test
	void addNegTest() {
	assertEquals(-55,math.addition(-50,-5));
	}
	@Test
	void addNegPosTest() {
	assertEquals(48,math.addition(-50,98));
	}
	@Test
	void commuTest() {
	assertEquals(math.addition(143,4542),math.addition(4542,143));
	}
	@Test
	void subtractionTest() {
	assertEquals(10,math.subtraction(100,90));
	}
	@Test
	void subtractNegpPosTest() {
	assertEquals(190,math.subtraction(100,-90));
	}
	@Test
	void subtractPosNegpTest() {
	assertEquals(-885,math.subtraction(-765,120));
	}
	@Test
	void multiplicationTest() {
	assertEquals(9000,math.multiply(100,90));
	}
	@Test
	void multiplyNegTest() {
	assertEquals(-9000,math.multiply(100,-90));
	}
	@Test
	void commutMultiplicationTest() {
	assertEquals(math.multiply(90,100),math.multiply(100,90));
	}
	@Test
	void divisionTest() {
	assertEquals(0.11,math.division(90,789),0.1,"value calculated" + math.division(90,789) );
	}
	@Test
	void divisionByZeroTest() {
	Exception ex = assertThrows(Exception.class, () -> math.division(120,0));
	assertEquals("division by zero",ex.getMessage());
	}
	@Test
	void divideZeroTest()
	{
	assertEquals(0,math.division(0,123),0.1);
	}
	@Test
	void negativeDivisionTest(){
	assertEquals(-0.11,math.division(90,-789),0.1,"value calculated" + math.division(90,-789) );
	}
	@Test
	void factorialTest() {
	assertEquals(120,math.factorial_num(5));
	}
	@Test
	void factorialZeroTest() {
	assertEquals(1,math.factorial_num(0));
	}
	@Test
	void factorialNegtiveTest() {
	Exception ex= assertThrows(Exception.class,() -> math.factorial_num(-23));
	assertEquals("input is lesser than zero",ex.getMessage());
	}
	@Test
	void factorialOutOfBoundsTest() {
	Exception ex= assertThrows(Exception.class,() -> math.factorial_num(23));
	assertEquals("Input is greater than 15",ex.getMessage());
	}
	@Test
	void powerTest() {
	assertEquals(32,math.power(2,5));
	}
	@Test
	void powerDecimalTest() {
	assertEquals(0.001,math.power(0.01,2),0.01);
	}
	@Test
	void powerNegativeExponentTest() {
	assertEquals(0.0625,math.power(4,-2),0.01);
	}
	@Test
	void powerRootTest() {
	assertEquals(2,math.power(4,0.5),0.01);
	}
	@Test
	void powerGreaterThanTenTest() {
	Exception ex= assertThrows(Exception.class,() -> math.power(3,12));
	assertEquals("exponent greater than 10",ex.getMessage());
	}
	}


}
